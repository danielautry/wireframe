function scrollToBottom() {
    $('html, body').animate({ scrollTop: $('#div-2').offset().top }, 1000);
    return false;
}

function scrollToTop() {
    $('html, body').animate({ scrollTop: $('#div-1').offset().top }, 1000);
    return false;
}

function hideImage() {
	document.getElementById('puppy').style.display = 'none';
}

function showImage() {
	document.getElementById('puppy').style.display = 'inline-block';
}

function fadeImageIn() {
	$('#puppy').hide();
	$('#puppy').fadeIn(3000);
}

function fadeImageOut() {
	$('#puppy').show();
	$('#puppy').fadeOut(3000);
}

$(window).scroll(function () {
    console.log($(window).scrollTop());
    var topDivHeight = $(".div-3").height();
    var viewPortSize = $(window).height();
    
    var triggerAt = 2000;
    var triggerHeight = (topDivHeight - viewPortSize) + triggerAt;

    if ($(window).scrollTop() >= triggerHeight) {
        $('.div-4').css('visibility', 'visible').hide().fadeIn();
        $(this).off('scroll');
    }
});